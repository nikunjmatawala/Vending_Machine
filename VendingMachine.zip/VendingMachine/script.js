﻿function checkSelectedItems(fitmprice, fiChkId) {

    if (document.getElementById(fiChkId).checked) {
        var litmprice = parseInt(fitmprice);
        var liMoney = parseInt(document.getElementById("hidMoney").value);
        var liTotalAmount = parseInt(document.getElementById("hidTotalAmount").value);
        var liLeftAmount = parseInt(document.getElementById("hidLeftAmount").value);

        if (litmprice <= liLeftAmount) {
            liTotalAmount = liTotalAmount + litmprice;
            liLeftAmount = liLeftAmount - litmprice;

            document.getElementById("hidTotalAmount").value = liTotalAmount;
            document.getElementById("hidLeftAmount").value = liLeftAmount;
            document.getElementById("hidSelectedItems").value = document.getElementById("hidSelectedItems").value + fiChkId + ",";
        }
        else {
            document.getElementById(fiChkId).checked = false;
        }
    }
    else {
        var litmprice = parseInt(fitmprice);
        var liTotalAmount = parseInt(document.getElementById("hidTotalAmount").value);
        var liLeftAmount = parseInt(document.getElementById("hidLeftAmount").value);

        liTotalAmount = liTotalAmount - litmprice;
        liLeftAmount = liLeftAmount + litmprice;

        document.getElementById("hidTotalAmount").value = liTotalAmount;
        document.getElementById("hidLeftAmount").value = liLeftAmount;
        document.getElementById("hidSelectedItems").value = document.getElementById("hidSelectedItems").value.replace(fiChkId + ",", "");
    }
}