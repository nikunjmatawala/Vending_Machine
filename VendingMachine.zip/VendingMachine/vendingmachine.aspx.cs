﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using Vendingmachine;

public partial class vendingmachine : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        

    }

    public bool getInventories()
    {
        clsInventory loInventory = new clsInventory();
        List<Inventory> loInventories = null;
        StringBuilder tblInventory = new StringBuilder("");
        int iColumnCount = 1;

        if (Session["inv"] != null)
            loInventories = (List<Inventory>)Session["inv"];
        else
        {
            loInventories = loInventory.getInventories();
            Session["inv"] = loInventories;
        }

        if (loInventories.Count > 0)
        {
            tblInventory.AppendLine("<table style=\"width:100%;cells-padding:2px;cells-spacing:2px;border:1px solid;text-align:center;\"><tr>");

            foreach (Inventory itm in loInventories)
            {
                if (iColumnCount < 11)
                {
                    tblInventory.AppendLine("<td style=\"cells-padding:2px;cells-spacing:2px;border:1px solid;\"><div>" +
                        itm.InverntoryName + "<hr/>" + "<input type='checkbox' id='chk" + itm.InventoryId + "' onclick='javascript:checkSelectedItems(" + itm.InventoryPrice.ToString() +
                        ",\"chk" + itm.InventoryId + "\");' /> " + itm.InventoryPrice.ToString("C") +
                        "</div></td>");

                    if (iColumnCount == 10)
                        tblInventory.AppendLine("</tr><tr>");

                    iColumnCount++;
                }
                else if (iColumnCount < 21)
                {
                    tblInventory.AppendLine("<td style=\"cells-padding:2px;cells-spacing:2px;border:1px solid;\"><div>" +
                         itm.InverntoryName + "<hr/>" + "<input type='checkbox' id='chk" + itm.InventoryId + "' onclick='javascript:checkSelectedItems(" + itm.InventoryPrice.ToString() +
                         ",\"chk" + itm.InventoryId + "\");' /> " + itm.InventoryPrice.ToString("C") +
                         "</div></td>");

                    if (iColumnCount == 20)
                        tblInventory.AppendLine("</tr><tr>");

                    iColumnCount++;
                }
                else
                {
                    tblInventory.AppendLine("<td style=\"cells-padding:2px;cells-spacing:2px;border:1px solid;\"><div>" +
                        itm.InverntoryName + "<hr/>" + "<input type='checkbox' id='chk" + itm.InventoryId + "' onclick='javascript:checkSelectedItems(" + itm.InventoryPrice.ToString() +
                        ",\"chk" + itm.InventoryId + "\");' /> " + itm.InventoryPrice.ToString("C") +
                        "</div></td>");

                    if (iColumnCount == 30)
                        tblInventory.AppendLine("</tr><tr>");
                }
            }

            tblInventory.AppendLine("</table>");
            divInventory.InnerHtml = tblInventory.ToString();

            return true;           
        }
        else
            return false;
    }

    protected void btnSelectItems_Click(object sender, EventArgs e)
    {
        if (Convert.ToInt32(txtMoney.Text) == 1 || Convert.ToInt32(txtMoney.Text) == 2 ||
            Convert.ToInt32(txtMoney.Text) == 5 || Convert.ToInt32(txtMoney.Text) == 10)
        {
            lblError.Visible = false; hidMoney.Value = txtMoney.Text; hidLeftAmount.Value = txtMoney.Text;
            
            if (getInventories())
            {
                //Disable some input controls
                txtMoney.Enabled = false; btnSelectItems.Enabled = false; lblFinalBill.Visible = false; lblFinalBill.Text = "";

                //Enable some other controls
                btnPurchase.Visible = true; btnReturnMoney.Visible = true;
            }
            else
            {
                lblFinalBill.Visible = true;
                lblFinalBill.Text = "All items are sold out, please come another day. Here is your $" + hidMoney.Value;
                divInventory.InnerHtml = ""; btnPurchase.Visible = false; btnReturnMoney.Visible = false;
            }
        }
        else
        {
            lblError.Visible = true; divInventory.InnerHtml = ""; lblFinalBill.Text = ""; lblFinalBill.Visible = false;
            lblError.Text = "Vending Machine only accept $1 or $2 coins and $5 or $10 bills";
        }
    }

    protected void btnPurchase_Click(object sender, EventArgs e)
    {
        if ((Convert.ToInt32(hidTotalAmount.Value) <= Convert.ToInt32(hidMoney.Value)) &&
            !Convert.ToInt32(hidTotalAmount.Value).Equals(0))
        {
            int liYourChange = Convert.ToInt32(hidMoney.Value) - Convert.ToInt32(hidTotalAmount.Value);
            lblFinalBill.Visible = true;

            if (liYourChange == 0)
                lblFinalBill.Text = "You have successfuly purchased your items.";
            else
                lblFinalBill.Text = "You have successfuly purchased your items. And here is your change: " + liYourChange.ToString("C");
            
            updateInventory();

            txtMoney.Enabled = true; txtMoney.Text = ""; btnSelectItems.Enabled = true;
            hidMoney.Value = "0"; hidLeftAmount.Value = "0"; hidSelectedItems.Value = "";
            hidTotalAmount.Value = "0"; btnPurchase.Visible = false; btnReturnMoney.Visible = false;
        }
        else
        {
            lblFinalBill.Visible = true;
            lblFinalBill.Text = "Please select any item.";
        }
    }

    protected void btnReturnMoney_Click(object sender, EventArgs e)
    {
        lblFinalBill.Visible = true; btnPurchase.Visible = false; btnReturnMoney.Visible = false;
        txtMoney.Enabled = true; btnSelectItems.Enabled = true; txtMoney.Text = "";
        lblFinalBill.Text = "Please collect your $" + hidMoney.Value + " back";
        hidMoney.Value = "0"; hidLeftAmount.Value = "0"; hidSelectedItems.Value = "";
        hidTotalAmount.Value = "0"; divInventory.InnerHtml = "";
    }

    public void updateInventory()
    {
        String[] selectedItems = hidSelectedItems.Value.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);
        List<Inventory> loLeftItems = (List<Inventory>)Session["inv"];
        
        foreach (string itm in selectedItems)
        {
            int liInvId = Convert.ToInt32(itm.Substring(3));
            int liIndex = loLeftItems.FindIndex(x => x.InventoryId.Equals(liInvId));
            loLeftItems.RemoveAt(liIndex);
        }

        Session["inv"] = loLeftItems;
        getInventories();
    }
}