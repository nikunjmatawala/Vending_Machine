﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for clsInventory
/// </summary>
namespace Vendingmachine
{
    public class clsInventory
    {
        public clsInventory()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public List<Inventory> getInventories()
        {
            List<Inventory> liInventories = new List<Inventory>();
            Inventory loInventory = null;

            /*Fill the inventiory list*/
            int iCount = 1;

            for (int i = 1; i <= 30; i++)
            {
                loInventory = new Inventory();

                loInventory.InventoryId = i;
                if (iCount < 11)
                    loInventory.InventoryPrice = 1;
                else if (iCount < 21)
                    loInventory.InventoryPrice = 2;
                else
                    loInventory.InventoryPrice = 5;
                loInventory.InverntoryName = "item" + i.ToString();

                liInventories.Add(loInventory);

                iCount++;
            }

            return liInventories;
        }
    }

    public class Inventory
    {
        private int inInventoryId;
        private string stInventoryName;
        private double inInventorryPrice;

        public int InventoryId
        {
            get { return inInventoryId; }
            set { inInventoryId = value; }
        }

        public string InverntoryName
        {
            get { return stInventoryName; }
            set { stInventoryName = value; }
        }

        public double InventoryPrice
        {
            get { return inInventorryPrice; }
            set { inInventorryPrice = value; }
        }
    }
}